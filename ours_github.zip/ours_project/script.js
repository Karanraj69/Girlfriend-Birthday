/* ═══════════════════════════════════════════
   OURS — A Love Story  |  script.js
   ═══════════════════════════════════════════ */

/* ─────────────────────────────────────────────
   ★ CUSTOMIZE EVERYTHING BELOW THIS LINE ★
   ───────────────────────────────────────────── */

const CONFIG = {

  /* 1. PASSWORD
     She types this to unlock the site. Keep it something personal.
     Example: "buttercup", "mystar", "softy" */
  password: "idiot",

  /* 2. YOUR NAME (shown at the bottom) */
  yourName: "Someone",

  /* 3. HER NAME (used in the hero and letter) */
  herName: "My Love",

  /* 4. GALLERY PHOTOS
     Replace the src values with your own image filenames.
     Put all images in an "images/" folder inside the project folder.
     Example src: "images/firstdate.jpg"
     Leave caption empty ("") if you don't want one shown. */
        photos: [
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "our little moment" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "my favourite rabbit" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "my favourite ghost" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "when you scream my name" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "blur but memorable" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "how depression looks like" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "someone wants icecream" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "did someone said boiling his blood?" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "when someone knows they are gonna get scolded now" },
    { src: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MDAiIGhlaWdodD0iNjAwIiBzdHlsZT0iYmFja2dyb3VuZDp3aGl0ZSI+CiAgPHJlY3Qgd2lkdGg9IjYwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IndoaXRlIiBzdHJva2U9IiNlOGE0OWMiIHN0cm9rZS13aWR0aD0iNCIvPgogIDx0ZXh0IHg9IjMwMCIgeT0iMjgwIiBmb250LWZhbWlseT0iR2VvcmdpYSxzZXJpZiIgZm9udC1zaXplPSIzNiIgZmlsbD0iI2M5N2I3YiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+YWRkIHBpYzwvdGV4dD4KICA8dGV4dCB4PSIzMDAiIHk9IjM0MCIgZm9udC1mYW1pbHk9Ikdlb3JnaWEsc2VyaWYiIGZvbnQtc2l6ZT0iMjIiIGZpbGw9IiNlOGE0OWMiIHRleHQtYW5jaG9yPSJtaWRkbGUiPnlvdXIgbWVtb3J5IGhlcmU8L3RleHQ+Cjwvc3ZnPg==", caption: "when someone is getting scolded" },
  ],

  /* 5. REASONS I LOVE YOU
     Replace with your real reasons. Be specific — generic is boring.
     "You always save me the first bite" beats "You're so kind." */
    reasons: [
    "I love how soft you are, even in a harsh world.",
    "I love that your beauty isn't just seen, it's felt.",
    "I love how you just scream your name when things are in chaos.",
    "I love the way your presence makes everything quieter inside me.",
    "I love our first hug—it felt like something finally i found.",
    "I love that hug in the lift—it felt like time paused for us.",
    "I love how you made your first birthday with me unforgettable.",
    "I love the way you act on video calls, like you forget the world exists.",
    "I love your unfiltered, real self when you're just being you.",
    "I love that your smiles aren't perfect—they're honest.",
    "I love your scars, not despite them, but because they tell your story.",
    "I love that you trust me enough to show your fears.",
    "I love that I don't need you to be perfect to love you.",
    "I love the way you made me more understanding.",
    "I love that I became easier to talk to because of you.",
    "I love that you changed me without forcing me.",
    "I love the way your eyes soften when you look at me.",
    "I love how your expressions say things words cannot define.",
    "I love the way you pose in pictures like the world is watching you.",
    "I love that even your smallest habits stay in my mind.",
    "I love that \"intel\" became something only we understand.",
    "I love that we have our own little language.",
    "I love how you fight through your physical struggles every day.",
    "I love your strength when you are alone but still decide to fight.",
    "I love that you don't give up, even when it's hard.",
    "I love how you handled your 10th boards with pressure on your shoulders.",
    "I love that you kept going even on days you didn't want to.",
    "I love that you chose to wake up even when it felt heavy.",
    "I love your silent battles that no one else sees.",
    "I love how strong you are, even when you don't feel it.",
    "I love that you call me just to hear my voice.",
    "I love that you text me and check on my day.",
    "I love that you care about the small details in my life.",
    "I love how you make me feel noticed.",
    "I love how you make me feel chosen.",
    "I love that your care isn't loud, but it's constant.",
    "I love how you show love in simple ways.",
    "I love that you stay, even when things aren't easy.",
    "I love the comfort you bring when i just see you and get in your arms.",
    "I love that you became my safe place.",
    "I love imagining a future with you.",
    "I love the thought of building a family together.",
    "I love that you are part of my long-term dreams.",
    "I love that you make the future feel real, not scary.",
    "I love that \"us\" feels like something permanent.",
    "I love that you gave meaning to the word \"home.\"",
    "I love that I don't have to pretend around you.",
    "I love that you see me as I am.",
    "I love that you stayed even after seeing my flaws.",
    "I love you, not for one reason—but for a thousand I still can't fully explain.",
    "I love the way you say my name.",
    "I love how your voice feels like comfort to me.",
    "I love the little pauses you take while talking.",
    "I love how you listen, not just hear.",
    "I love how you make ordinary moments feel special.",
    "I love the calm you bring into my life.",
    "I love how you don't need to try to be perfect.",
    "I love how natural you are with me.",
    "I love the warmth in your presence.",
    "I love how being with you feels like peace.",
    "I love the way your eyes tell stories.",
    "I love how your expressions change in tiny ways.",
    "I love how you look at me when you're happy.",
    "I love how you look at me when you're quiet.",
    "I love how you don't hide your emotions from me.",
    "I love that you trust me with your real self.",
    "I love how gentle your heart is.",
    "I love how deeply you feel things.",
    "I love how your kindness shows in small actions.",
    "I love how pure your intentions are.",
    "I love how you care with softness and patience.",
    "I love how you check on me even when you're tired.",
    "I love how you remember little things about me.",
    "I love how you make me feel important.",
    "I love how you give your time to me.",
    "I love how you stay present when we talk.",
    "I love how you make distance feel smaller.",
    "I love how you make silence feel comfortable.",
    "I love how you understand me without words.",
    "I love how you make me feel seen.",
    "I love how you try, even on difficult days.",
    "I love how you keep going, no matter what.",
    "I love your quiet strength.",
    "I love your courage, even when you doubt yourself.",
    "I love how you don't give up even when everyone says to.",
    "I love how you don't give up on us and tries evey single time.",
    "I love how you face your struggles with heart.",
    "I love how you rise again, even after hard moments.",
    "I love how strong you are in ways no one notices.",
    "I love how you inspire me just by being you.",
    "I love how you make me want to be better.",
    "I love how you changed the way I see love.",
    "I love how you made my world softer.",
    "I love how you brought light into my life.",
    "I love how you made me believe in something real.",
    "I love how you became part of my everyday thoughts.",
    "I love how you became part of my dreams.",
    "I love how you feel like home to me.",
    "I love how loving you feels natural.",
    "I love how you turned simple feelings into something beautiful.",
    "I love how you stayed, even when life tried to pull you away.",
    "I love how you chose to keep going, no matter even when on one is their.",
    "I love that your heart still believes in love.",
    "I love that you didn't let pain take away your softness.",
    "I love how you still find reasons to smile.",
    "I love how you still give love, even when you needed it most.",
    "I love how you let me be part of your life.",
    "I love how you trusted me with your heart.",
    "I love how you didn't give up on us.",
    "I love how you hold on, even when things feel uncertain.",
    "I love that you are stronger than you think you are.",
    "I love that even in your weakest moments, you shine.",
    "I love how your existence itself feels special to me.",
    "I love how you make my life feel complete.",
    "I love how you became someone I can't imagine losing.",
    "I love how you turned into my safe place without trying.",
    "I love how you understand me in ways no one else does.",
    "I love how you accept me, even when I'm not at my best.",
    "I love how you make me feel worthy of love.",
    "I love how you changed my definition of happiness.",
    "I love how every moment with you feels meaningful.",
    "I love how even your silence speaks to me.",
    "I love how your presence makes everything better.",
    "I love how you bring calm into my chaos.",
    "I love how you became my peace in a noisy world.",
    "I love how you make love feel simple and real.",
    "I love how you don't need grand things to make me happy.",
    "I love how just \"you\" is enough for me.",
    "I love how you made me believe in forever.",
    "I love how you made me believe in us.",
    "I love how I see my future when I look at you.",
    "I love how I imagine a family with you.",
    "I love how you became part of every plan I make.",
    "I love how loving you feels like the right thing.",
    "I love how you gave meaning to my life in a quiet way.",
    "I love how you became the reason behind my smiles.",
    "I love how you became the reason I keep going.",
    "I love how you are not just part of my story—you are my story.",
    "I love how you are my today and my tomorrow.",
    "I love how you are my favorite person in this world.",
    "I love you for more then this.",
    "I love you for who you are.",
    "I LOVE YOU SO MUCH HER NAME",
  ],

  /* 6. RELATIONSHIP TIMELINE
     Add or remove entries. dates are just labels — write them however you like. */
  timeline: [
    {
      date: "The beginning",
      event: "We met",
      desc: "I still don't know how I got that lucky. You walked in and honestly the rest is a history.",
      emoji: "✨"
    },
    {
      date: "A little later",
      event: "Our first meet",
      desc: "Two souls adrift in the same moment — we held hands, and without a word, understood we were everything to each other.",
      emoji: "🌸"
    },
    {
      date: "That one night",
      event: "I knew I loved you",
      desc: "We were talking about nothing important and I just… knew. You were it.",
      emoji: "💛"
    },
    {
      date: "Not long after",
      event: "You said it",
      desc: "Those words weren't there but the feeling was — on the call.",
      emoji: "💬"
    },
    {
      date: "Valentine's",
      event: "Our first biggest fight",
      desc: "Every small moment we were there — talking, fighting, existing. What we didn't know was that with every word, every silence, every storm, we were only getting closer.",
      emoji: "🩹"
    },
    {
      date: "Today",
      event: "Your birthday 🎂",
      desc: "Another year of you. Another year of us. I am so grateful for every single day.",
      emoji: "🎉"
    },
  ],

  /* 7. LOVE LETTER
     Write it from the heart. Use \n\n for paragraph breaks. */
  letterFrom: "Someone",   /* How you sign it */
  letterBody: `There are moments with you that don't feel like memories, but like something my hands still remember till I die. It wasn't long ago—the way I held you once, folded into me, hurting—and I didn't know how to fix anything, so I just held you close enough that the world might forget to hurt you for a while. Your head on my shoulder, my hands tapping your back—not like a solution I had read, but something I promised you, saying, "I am there with you."

And somehow, in all your fear, you still worried I would be the one to leave—that one day your scars would weigh too much, or your storms would make me step back. I was looking at you, saying, "Really? You think that?" and saying to myself, "How idiotic she is." But what I miss is: I don't want things to be in perfection, nor do I want you to be the perfect hider. And as I walked in, saw everything, and still chose to stay—not out of pity or habit, but because something between your broken pieces I found something more honest than anything whole. In some pieces, I saw myself. It was just the time I found you in totally shattered parts, and you were picking them up while hurting yourself. But I still found the her name who laughed sometimes, smiled at the dimmest thing by acting like a kid who forgot pain exists, by being just yourself—and that just made me think how the same person bears so much. And that's the part of you I don't just love, but the part that saves me too.

In this, I won't promise to be perfect forever or say nothing's gonna hurt you again—because that wouldn't be love; that would be a lie. But I will say this and mean every word: When things get heavy for you, when the silence grows, when your fears get louder than the scream of "your nameeee!"—yes, I won't disappear, but I'll probably hold you the same way even after years, tap your back like a kid in arms. And many years from now, everything might change, but this won't—not the words, not the promise, but the feeling of being held like you were never too much to stay for.

And on this birthday of my little princess, I want to tell you: Every moment you thought to end this life, every night you stayed awake or struggled, every moment of the health you fought and thought death was better—those years you survived—I am so grateful that you are here, that you were born. With this, I would like to say: Happy birthday to my little princess.`,

  /* 8. MEMORY JAR
     These are the little notes she pulls from the jar.
     Make them specific — inside jokes, real moments, tiny things she loves. */
        memories: [
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
    { icon: "🎀", text: "insert your own text" },
  ],
};

/* ─────────────────────────────────────────────
   ★ END OF CUSTOMIZATION ZONE ★
   Don't need to edit below unless you're comfortable with code.
   ───────────────────────────────────────────── */


/* ══════════════════════════════════════════
   PASSWORD GATE
══════════════════════════════════════════ */
function checkPassword() {
  const input = document.getElementById('pw-input').value.trim().toLowerCase();
  const expected = CONFIG.password.toLowerCase();

  if (input === expected) {
    unlockApp();
  } else {
    const err = document.getElementById('pw-error');
    err.textContent = 'Hmm… try again. You know this one 💛';
    document.getElementById('pw-input').style.borderColor = 'var(--deeprose)';
    shakeInput();
  }
}

function shakeInput() {
  const wrap = document.querySelector('.input-wrap');
  wrap.style.transform = 'translateX(-8px)';
  setTimeout(() => wrap.style.transform = 'translateX(8px)', 80);
  setTimeout(() => wrap.style.transform = 'translateX(-5px)', 160);
  setTimeout(() => wrap.style.transform = 'translateX(0)', 240);
}

document.getElementById('pw-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') checkPassword();
});

function unlockApp() {
  const gate = document.getElementById('password-gate');
  gate.classList.add('fade-out');
  setTimeout(() => {
    gate.style.display = 'none';
    document.getElementById('app').classList.remove('hidden');
    initApp();
  }, 850);
}

// Spawn petals on the gate screen
spawnGatePetals();

function spawnGatePetals() {
  const container = document.getElementById('gate-petals');
  const petals = ['🌸', '🌺', '✿', '❀', '🌷'];
  setInterval(() => {
    const petal = document.createElement('span');
    petal.textContent = petals[Math.floor(Math.random() * petals.length)];
    petal.style.cssText = `
      position: absolute;
      left: ${Math.random() * 100}%;
      top: -30px;
      font-size: ${0.8 + Math.random() * 0.8}rem;
      opacity: 0.7;
      animation: petalFall ${4 + Math.random() * 4}s linear forwards;
    `;
    container.appendChild(petal);
    setTimeout(() => petal.remove(), 8000);
  }, 600);
}


/* ══════════════════════════════════════════
   INIT APP
══════════════════════════════════════════ */
function initApp() {
  setNames();
  buildReasons();
  buildTimeline();
  buildLetter();
  buildJar();
  startPetalRain();
  initScrollAnimations();
  buildHeroHearts();
}

/* Set name references */
function setNames() {
  document.getElementById('footer-name').textContent = CONFIG.yourName;
  document.getElementById('letter-from').textContent = CONFIG.letterFrom;
}


/* ══════════════════════════════════════════
   GALLERY
══════════════════════════════════════════ */
function buildGallery() {
  const grid = document.getElementById('gallery-grid');
  CONFIG.photos.forEach((photo, i) => {
    const item = document.createElement('div');
    item.className = 'gallery-item fade-in-up';
    item.innerHTML = `
      <img src="${photo.src}" alt="${photo.caption || 'Our memory #' + (i+1)}" loading="lazy" />
      <div class="gallery-overlay">
        <span class="gallery-caption">${photo.caption || ''}</span>
      </div>
    `;
    item.addEventListener('click', () => openLightbox(photo.src, photo.caption));
    grid.appendChild(item);
  });
}




/* ══════════════════════════════════════════
   REASONS
══════════════════════════════════════════ */
let currentReason = 0;

function buildReasons() {
  showReason(0, false);
  buildDots();
}

function buildDots() {
  const dotsWrap = document.getElementById('reasons-dots');
  dotsWrap.innerHTML = '';
  CONFIG.reasons.forEach((_, i) => {
    const dot = document.createElement('div');
    dot.className = 'dot' + (i === 0 ? ' active' : '');
    dot.addEventListener('click', () => goToReason(i));
    dotsWrap.appendChild(dot);
  });
}

function showReason(index, animate = true) {
  const card = document.getElementById('reasons-card');
  const textEl = document.getElementById('reason-text');
  const numEl = document.getElementById('reason-number');
  const counter = document.getElementById('reason-counter');

  if (animate) {
    card.classList.add('reason-slide-out');
    setTimeout(() => {
      updateReasonContent(index, textEl, numEl, counter);
      card.classList.remove('reason-slide-out');
      card.classList.add('reason-slide-in');
      setTimeout(() => card.classList.remove('reason-slide-in'), 350);
    }, 300);
  } else {
    updateReasonContent(index, textEl, numEl, counter);
  }

  // Update dots
  document.querySelectorAll('.dot').forEach((d, i) => {
    d.classList.toggle('active', i === index);
  });
}

function updateReasonContent(index, textEl, numEl, counter) {
  textEl.textContent = CONFIG.reasons[index];
  numEl.textContent = `#${index + 1}`;
  counter.textContent = `${index + 1} / ${CONFIG.reasons.length}`;
}

function nextReason() {
  currentReason = (currentReason + 1) % CONFIG.reasons.length;
  showReason(currentReason);
  burstHeart();
}

function prevReason() {
  currentReason = (currentReason - 1 + CONFIG.reasons.length) % CONFIG.reasons.length;
  showReason(currentReason, true);
}

function goToReason(index) {
  currentReason = index;
  showReason(currentReason);
}

/* Mini heart burst on next */
function burstHeart() {
  const btn = document.querySelector('.btn-primary');
  const rect = btn.getBoundingClientRect();
  for (let i = 0; i < 5; i++) {
    const h = document.createElement('span');
    h.textContent = ['❤️','🩷','💕','💗','💖'][i];
    h.style.cssText = `
      position: fixed;
      left: ${rect.left + rect.width/2}px;
      top: ${rect.top}px;
      font-size: ${0.8 + Math.random()*0.6}rem;
      pointer-events: none;
      z-index: 9999;
      animation: burstFly 0.8s ease forwards;
      --tx: ${(Math.random()-0.5)*80}px;
      --ty: ${-(30 + Math.random()*60)}px;
    `;
    document.body.appendChild(h);
    setTimeout(() => h.remove(), 850);
  }
}

const burstStyle = document.createElement('style');
burstStyle.textContent = `
  @keyframes burstFly {
    from { opacity: 1; transform: translate(0, 0) scale(1); }
    to   { opacity: 0; transform: translate(var(--tx), var(--ty)) scale(0.5); }
  }
`;
document.head.appendChild(burstStyle);


/* ══════════════════════════════════════════
   TIMELINE
══════════════════════════════════════════ */
function buildTimeline() {
  const wrap = document.getElementById('timeline-wrap');
  CONFIG.timeline.forEach((item, i) => {
    const el = document.createElement('div');
    el.className = 'timeline-item fade-in-up';
    el.style.animationDelay = `${i * 0.1}s`;
    el.innerHTML = `
      <div class="timeline-emoji">${item.emoji}</div>
      <div class="timeline-date">${item.date}</div>
      <div class="timeline-event">${item.event}</div>
      <div class="timeline-desc">${item.desc}</div>
    `;
    wrap.appendChild(el);
  });
}


/* ══════════════════════════════════════════
   LOVE LETTER
══════════════════════════════════════════ */
function buildLetter() {
  // Set today's date nicely
  const formatted = 'Wednesday, 7th of May, 2025';
  document.getElementById('letter-date').textContent = formatted;

  // Build paragraphs
  const bodyEl = document.getElementById('letter-body');
  const paragraphs = CONFIG.letterBody.trim().split('\n\n');
  bodyEl.innerHTML = paragraphs.map(p => `<p>${p.trim()}</p>`).join('');
}

function openLetter() {
  const envelope = document.getElementById('letter-envelope');
  const content = document.getElementById('letter-content');

  envelope.style.animation = 'letterUnfold 0.6s ease forwards';
  setTimeout(() => {
    envelope.classList.add('hidden');
    content.classList.remove('hidden');
    content.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 500);
}


/* ══════════════════════════════════════════
   MEMORY JAR
══════════════════════════════════════════ */
const noteColors = ['#f9d7d2','#fde9c9','#d9ecd0','#d4e8f7','#e8d5f7','#fdf2c0'];

function buildJar() {
  const notesWrap = document.getElementById('jar-notes');
  // Fill with decorative note bits
  for (let i = 0; i < 18; i++) {
    const note = document.createElement('div');
    note.className = 'jar-note-bit';
    note.style.background = noteColors[i % noteColors.length];
    note.style.setProperty('--nd', `${Math.random() * 2}s`);
    note.style.setProperty('--nr', `${(Math.random()-0.5)*12}deg`);
    note.style.transform = `rotate(${(Math.random()-0.5)*12}deg)`;
    notesWrap.appendChild(note);
  }
}

let usedMemories = [];

function pickMemory() {
  // Reset if all used
  if (usedMemories.length >= CONFIG.memories.length) usedMemories = [];

  // Pick unused memory
  const remaining = CONFIG.memories.filter((_, i) => !usedMemories.includes(i));
  const idx = CONFIG.memories.indexOf(remaining[Math.floor(Math.random() * remaining.length)]);
  usedMemories.push(idx);

  const memory = CONFIG.memories[idx];
  document.getElementById('memory-icon').textContent = memory.icon;
  document.getElementById('memory-text').textContent = memory.text;

  const card = document.getElementById('jar-memory-card');
  card.classList.remove('hidden');

  // Force re-animation
  const paper = card.querySelector('.memory-paper');
  paper.style.animation = 'none';
  paper.offsetHeight; // reflow
  paper.style.animation = '';

  document.getElementById('jar-container').style.transform = 'scale(0.95)';
  setTimeout(() => document.getElementById('jar-container').style.transform = '', 300);
}

function closeMemory() {
  document.getElementById('jar-memory-card').classList.add('hidden');
}


/* ══════════════════════════════════════════
   PETAL RAIN
══════════════════════════════════════════ */
function startPetalRain() {
  const petalSymbols = ['🌸','🌺','🌷','✿','❀','🌼'];
  const layer = document.getElementById('petals-layer');

  function spawnPetal() {
    const p = document.createElement('span');
    p.className = 'petal';
    p.textContent = petalSymbols[Math.floor(Math.random() * petalSymbols.length)];
    const duration = 5 + Math.random() * 6;
    p.style.cssText = `
      left: ${Math.random() * 100}vw;
      font-size: ${0.7 + Math.random() * 0.9}rem;
      animation-duration: ${duration}s;
    `;
    layer.appendChild(p);
    setTimeout(() => p.remove(), duration * 1000 + 100);
  }

  // Initial burst
  for (let i = 0; i < 8; i++) setTimeout(spawnPetal, i * 300);
  // Continuous gentle fall
  setInterval(spawnPetal, 1200);
}


/* ══════════════════════════════════════════
   HERO HEARTS
══════════════════════════════════════════ */
function buildHeroHearts() {
  const wrap = document.getElementById('hero-hearts');
  const positions = [
    {left:'8%',  top:'20%'}, {left:'85%', top:'15%'},
    {left:'15%', top:'70%'}, {left:'78%', top:'65%'},
    {left:'50%', top:'10%'}, {left:'5%',  top:'45%'},
    {left:'90%', top:'45%'}, {left:'40%', top:'85%'},
  ];
  positions.forEach((pos, i) => {
    const h = document.createElement('span');
    h.className = 'floating-heart';
    h.textContent = ['♡','♡','♡','❤','🩷','💕'][i % 6];
    h.style.cssText = `
      left: ${pos.left}; top: ${pos.top};
      --dur: ${3 + Math.random() * 3}s;
      --delay: ${Math.random() * 2}s;
    `;
    wrap.appendChild(h);
  });
}


/* ══════════════════════════════════════════
   SCROLL ANIMATIONS
══════════════════════════════════════════ */
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('.fade-in-up').forEach(el => observer.observe(el));
}


/* ══════════════════════════════════════════
   NAV SCROLL EFFECT
══════════════════════════════════════════ */
window.addEventListener('scroll', () => {
  const nav = document.getElementById('main-nav');
  if (nav) {
    nav.style.boxShadow = window.scrollY > 30
      ? '0 4px 24px rgba(74,54,48,0.1)'
      : 'none';
  }
});

  
/* ══════════════════════════════════════════
   GALLERY — ENVELOPE + POLAROID CAROUSEL
══════════════════════════════════════════ */
let carouselIndex = 0;
let carouselAnimating = false;

function openGalleryEnvelope() {
  const env = document.getElementById('gallery-envelope');
  if (env.classList.contains('shaking')) return;

  env.classList.add('shaking');
  setTimeout(() => {
    env.classList.remove('shaking');
    env.style.display = 'none';
    const carousel = document.getElementById('polaroid-carousel');
    carousel.classList.remove('hidden');
    buildCarousel();
  }, 560);
}

function buildCarousel() {
  const stage = document.getElementById('carousel-stage');
  stage.innerHTML = '';

  CONFIG.photos.forEach((photo, i) => {
    const pol = document.createElement('div');
    pol.className = 'polaroid';
    pol.innerHTML = `<img src="${photo.src}" alt="${photo.caption}" draggable="false" />`;
    pol.addEventListener('click', () => {
      if (i !== carouselIndex) {
        carouselIndex = i;
        updateCarousel();
      }
    });
    stage.appendChild(pol);
  });

  buildCarouselDots();
  updateCarousel(false);
}

function buildCarouselDots() {
  const wrap = document.getElementById('carousel-dots');
  wrap.innerHTML = '';
  CONFIG.photos.forEach((_, i) => {
    const d = document.createElement('div');
    d.className = 'dot' + (i === 0 ? ' active' : '');
    d.addEventListener('click', () => { carouselIndex = i; updateCarousel(); });
    wrap.appendChild(d);
  });
}

function updateCarousel(animate = true) {
  const polaroids = document.querySelectorAll('.polaroid');
  const total = CONFIG.photos.length;

  polaroids.forEach((pol, i) => {
    const offset = ((i - carouselIndex) % total + total) % total;
    // offset: 0=center, 1=right1, 2=right2, total-1=left1, total-2=left2
    pol.className = 'polaroid';
    if (offset === 0)          pol.classList.add('pos-center');
    else if (offset === 1)     pol.classList.add('pos-right1');
    else if (offset === 2)     pol.classList.add('pos-right2');
    else if (offset === total - 1) pol.classList.add('pos-left1');
    else if (offset === total - 2) pol.classList.add('pos-left2');
    else if (offset > total / 2)   pol.classList.add('pos-hidden-left');
    else                           pol.classList.add('pos-hidden');
  });

  // Caption
  const cap = document.getElementById('polaroid-caption');
  cap.style.opacity = '0';
  setTimeout(() => {
    cap.textContent = CONFIG.photos[carouselIndex].caption;
    cap.style.opacity = '1';
  }, animate ? 200 : 0);

  // Dots
  document.querySelectorAll('#carousel-dots .dot').forEach((d, i) => {
    d.classList.toggle('active', i === carouselIndex);
  });
}

function slideCarousel(dir) {
  const total = CONFIG.photos.length;
  carouselIndex = ((carouselIndex + dir) % total + total) % total;
  updateCarousel();
}


function smoothTo(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}